<center>
  <hr />
    [ <a href="index.php">index.php</a> ] [ <a href="docs.php">docs.php</a> ] [ <a href="package.php">package.php</a> ] [ <a href="test.php">test.php</a> ] [ <a href="example.php">example.php</a> ] [ <a href="download.php">download.php</a> ]
  <hr />
</center>
