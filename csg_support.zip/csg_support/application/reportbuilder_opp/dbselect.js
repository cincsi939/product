<!-- 
	var obj1 = null;
	var dbname="";
	var tbname="";
	function SelectCondition(fld){
		obj1 = fld;
		sf = window.open("dbselect.php?action=init&type=cond&val="+fld.value+"&db="+dbname+"&tb="+tbname, 'selectfield','left=50,top=50,toolbar=0,location=0,directories=0,status=1, menubar=0,scrollbars=yes,resizable=yes,width=700,height=420');
		sf.focus();
	}

	function SelectField(fld){
		obj1 = fld;
		sf = window.open("dbselect.php?action=init&type=field&host=local&val="+fld.value+"&db="+dbname+"&tb="+tbname, 'selectfield','left=50,top=50,toolbar=0,location=0,directories=0,status=1, menubar=0,scrollbars=yes,resizable=yes,width=700,height=420');
		sf.focus();
	}

	function SelectMultiField(fld){
		obj1 = fld;
		sf = window.open("dbselect.php?action=init&type=field&select=multi&val="+fld.value+"&db="+dbname+"&tb="+tbname, 'selectfield','left=50,top=50,toolbar=0,location=0,directories=0,status=1, menubar=0,scrollbars=yes,resizable=yes,width=700,height=420');
		sf.focus();
	}
-->
