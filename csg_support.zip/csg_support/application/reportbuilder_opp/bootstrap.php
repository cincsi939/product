<?php
/**
 * @comment 	configulation database
 * @projectCode
 * @tor 	   
 * @package		core
 * @author		Phada Woodtikarn (phada@sapphire.co.th)
 * @created		10/09/2014
 * @access		public
 */
$db = array(
	/*'username' => 'cmss',
	'password' => '2010cmss',
	'host' => '192.168.2.111',
	'database_reportbuiler' => 'reportbuilder_wandc',
	'database_name' => 'wandc_master'*/
	
	/*'username' => 'cmss',
	'password' => '2010cmss',
	'host' => 'localhost',
	'database_reportbuiler' => 'reportbuilder_cmss_master',
	'database_name' => 'cmss_master'*/
	
	/*'username' => 'inside_system',
	'password' => 'System_$apph!re2014',
	'host' => 'localhost',
	'database_reportbuiler' => 'reportbuilder_office',
	'database_name' => 'dailyreport101'*/
	
	'username' => 'cmss',
	'password' => '2010cmss',
	'host' => '192.168.2.102',
	'database_reportbuiler' => 'reportbuilder_opp',
	'database_name' => 'opp_master'
);
?>