﻿for(var post=1;post<=784;post++){
iimSet("post",post);
iimPlay("CODE:\n"
	+"VERSION BUILD=8920312 RECORDER=FX\n"
	+"TAB T=1\n"
	+"SET !ERRORIGNORE YES\n"
	+"SET !ERRORCONTINUE YES\n"
	+"SET !TIMEOUT_STEP 0\n"
	+"SET !TIMEOUT_TAG 0\n"
	+"SET !DATASOURCE datalogin.csv\n"
	+"SET !LOOP {{post}}\n"
	+"URL GOTO=http://192.168.2.102/dcy_usermanager/application/login.php\n"
	+"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:form ATTR=ID:uname CONTENT={{!COL1}}\n"
	+"TAG POS=1 TYPE=INPUT:PASSWORD FORM=NAME:form ATTR=NAME:pwd CONTENT={{!COL2}}\n"
	+"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:form ATTR=NAME:submit\n"
	+"ADD !EXTRACT {{!URLCURRENT}}\n");
	iimDisplay(post);
extract = iimGetLastExtract();
if(extract == 'http://192.168.2.102/dcy_usermanager/application/login.php') {
iimSet("post",post);
	iimPlay("CODE: SET !EXTRACT NULL" + "\n"
	+"SET !DATASOURCE Book1.csv\n"
	+"SET !LOOP {{post}}\n"
	+"ADD !EXTRACT {{!COL1}}" + "\n"
	+"ADD !EXTRACT {{!COL2}}" + "\n"
	+"ADD !EXTRACT 0" + "\n"
	+"SAVEAS TYPE=EXTRACT FOLDER=* FILE=p1.csv\n");
}else{
iimSet("post",post);
	iimPlay("CODE: SET !EXTRACT NULL" + "\n"
	+"SET !DATASOURCE Book1.csv\n"
	+"SET !LOOP {{post}}\n"
	+"ADD !EXTRACT {{!COL1}}" + "\n"
	+"ADD !EXTRACT {{!COL2}}" + "\n"
	+"ADD !EXTRACT 1" + "\n"
	+"SAVEAS TYPE=EXTRACT FOLDER=* FILE=p1.csv\n");
}
iimPlay("CODE:\n"
+"TAG POS=1 TYPE=STRONG ATTR=TXT:ออกจากระบบ\n");
}